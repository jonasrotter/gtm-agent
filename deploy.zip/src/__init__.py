"""
GTM Agent - Solution Engineering Agent Package.

A multi-agentic system for Azure documentation research, architecture best practices,
and hypothesis validation.
"""

__version__ = "0.1.0"
__author__ = "Jonas Rotter"
