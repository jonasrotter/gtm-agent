"""
Semantic Kernel agent wrappers for multi-agent orchestration.

Provides base classes and utilities for integrating with Semantic Kernel's
ChatCompletionAgent and orchestration patterns.
"""

from typing import Any, Callable, Sequence

from semantic_kernel import Kernel
from semantic_kernel.agents import ChatCompletionAgent, AgentGroupChat
from semantic_kernel.connectors.ai.open_ai import AzureOpenAIChat
from semantic_kernel.connectors.ai.prompt_execution_settings import PromptExecutionSettings
from semantic_kernel.contents import ChatHistory, ChatMessageContent
from semantic_kernel.functions import KernelFunction, kernel_function

from src.config import get_settings
from src.lib.logging import get_logger


logger = get_logger(__name__)


class SemanticKernelAgentBase:
    """
    Base class for agents using Semantic Kernel's ChatCompletionAgent.
    
    Provides:
    - Kernel initialization with Azure OpenAI
    - ChatCompletionAgent creation with system prompts
    - Tool registration via KernelFunction decorators
    """
    
    def __init__(
        self,
        name: str,
        instructions: str,
        description: str | None = None,
    ) -> None:
        """
        Initialize a Semantic Kernel-based agent.
        
        Args:
            name: Agent name for identification
            instructions: System prompt/instructions for the agent
            description: Optional description of agent capabilities
        """
        self.name = name
        self.instructions = instructions
        self.description = description or f"{name} agent"
        
        self._kernel: Kernel | None = None
        self._agent: ChatCompletionAgent | None = None
        self._chat_history = ChatHistory()
        self._settings = get_settings()
        
    @property
    def kernel(self) -> Kernel:
        """Get or create the Semantic Kernel instance."""
        if self._kernel is None:
            self._kernel = self._create_kernel()
        return self._kernel
    
    def _create_kernel(self) -> Kernel:
        """
        Create and configure a Semantic Kernel instance.
        
        Returns:
            Configured Kernel with Azure OpenAI service.
        """
        kernel = Kernel()
        
        # Add Azure OpenAI chat service if configured
        if self._settings.azure_openai_endpoint and self._settings.azure_openai_deployment:
            try:
                from azure.identity import DefaultAzureCredential
                
                service = AzureOpenAIChat(
                    service_id="azure_openai",
                    deployment_name=self._settings.azure_openai_deployment,
                    endpoint=self._settings.azure_openai_endpoint,
                    ad_token_provider=DefaultAzureCredential(),
                )
                kernel.add_service(service)
                logger.info(
                    "Azure OpenAI service added to kernel",
                    deployment=self._settings.azure_openai_deployment,
                )
            except Exception as e:
                logger.warning(
                    "Failed to add Azure OpenAI service",
                    error=str(e),
                )
        
        return kernel
    
    @property
    def agent(self) -> ChatCompletionAgent:
        """Get or create the ChatCompletionAgent."""
        if self._agent is None:
            self._agent = self._create_agent()
        return self._agent
    
    def _create_agent(self) -> ChatCompletionAgent:
        """
        Create a ChatCompletionAgent with the configured kernel.
        
        Returns:
            Configured ChatCompletionAgent.
        """
        return ChatCompletionAgent(
            name=self.name,
            instructions=self.instructions,
            description=self.description,
            kernel=self.kernel,
        )
    
    def register_function(self, func: Callable) -> KernelFunction:
        """
        Register a function as a kernel function (tool).
        
        Args:
            func: The function to register
            
        Returns:
            The registered KernelFunction
        """
        kf = KernelFunction.from_method(func)
        self.kernel.add_function(kf)
        return kf
    
    async def invoke(self, message: str) -> str:
        """
        Invoke the agent with a message and get a response.
        
        Args:
            message: User message to process
            
        Returns:
            Agent response as string
        """
        self._chat_history.add_user_message(message)
        
        try:
            response = await self.agent.invoke(self._chat_history)
            
            # Extract response content
            if response and response.items:
                content = response.items[-1].content if response.items[-1].content else ""
                self._chat_history.add_assistant_message(content)
                return content
            
            return ""
            
        except Exception as e:
            logger.error(
                "Agent invocation failed",
                agent=self.name,
                error=str(e),
            )
            # Return empty string on failure, let caller handle
            return ""
    
    def clear_history(self) -> None:
        """Clear the chat history for a fresh conversation."""
        self._chat_history = ChatHistory()


class AgentOrchestrator:
    """
    Orchestrates multiple Semantic Kernel agents.
    
    Provides:
    - Agent registration and routing
    - Sequential and parallel execution patterns
    - Conversation context management
    """
    
    def __init__(self, name: str = "orchestrator") -> None:
        """
        Initialize the orchestrator.
        
        Args:
            name: Name for the orchestrator
        """
        self.name = name
        self._agents: dict[str, SemanticKernelAgentBase] = {}
        self._routing_agent: ChatCompletionAgent | None = None
        
    def register_agent(self, agent: SemanticKernelAgentBase) -> None:
        """
        Register an agent with the orchestrator.
        
        Args:
            agent: The agent to register
        """
        self._agents[agent.name] = agent
        logger.info(
            "Agent registered with orchestrator",
            agent_name=agent.name,
        )
    
    def get_agent(self, name: str) -> SemanticKernelAgentBase | None:
        """
        Get a registered agent by name.
        
        Args:
            name: Agent name
            
        Returns:
            The agent if found, None otherwise
        """
        return self._agents.get(name)
    
    @property
    def agent_names(self) -> list[str]:
        """Get list of registered agent names."""
        return list(self._agents.keys())
    
    async def route_and_invoke(
        self,
        message: str,
        target_agent: str | None = None,
    ) -> tuple[str, str]:
        """
        Route a message to the appropriate agent and get response.
        
        Args:
            message: The message to process
            target_agent: Optional specific agent to route to
            
        Returns:
            Tuple of (agent_name, response)
        """
        # If target specified, use it directly
        if target_agent and target_agent in self._agents:
            agent = self._agents[target_agent]
            response = await agent.invoke(message)
            return (target_agent, response)
        
        # Otherwise, use first available agent
        if self._agents:
            agent_name = next(iter(self._agents))
            agent = self._agents[agent_name]
            response = await agent.invoke(message)
            return (agent_name, response)
        
        return ("", "No agents available")


def create_kernel_function(
    name: str,
    description: str,
) -> Callable:
    """
    Decorator factory for creating kernel functions.
    
    Args:
        name: Function name
        description: Function description for the LLM
        
    Returns:
        Decorator that wraps the function as a KernelFunction
    """
    def decorator(func: Callable) -> Callable:
        return kernel_function(name=name, description=description)(func)
    return decorator


# Singleton instance
_orchestrator: AgentOrchestrator | None = None


def get_orchestrator() -> AgentOrchestrator:
    """Get the global orchestrator instance."""
    global _orchestrator
    if _orchestrator is None:
        _orchestrator = AgentOrchestrator()
    return _orchestrator
