"""
Custom exception classes for the Solution Engineering Agent.

Provides a hierarchy of exceptions for different error scenarios,
enabling proper error handling and user-friendly error messages.
"""

from typing import Any


class AgentError(Exception):
    """
    Base exception for all agent-related errors.

    Attributes:
        message: Human-readable error message.
        error_code: Machine-readable error code.
        details: Additional error details.
        suggestion: Actionable suggestion for resolution.
    """

    def __init__(
        self,
        message: str,
        error_code: str = "AGENT_ERROR",
        details: dict[str, Any] | None = None,
        suggestion: str | None = None,
    ) -> None:
        """
        Initialize the agent error.

        Args:
            message: Human-readable error message.
            error_code: Machine-readable error code.
            details: Additional error details.
            suggestion: Actionable suggestion for resolution.
        """
        super().__init__(message)
        self.message = message
        self.error_code = error_code
        self.details = details or {}
        self.suggestion = suggestion

    def to_dict(self) -> dict[str, Any]:
        """Convert exception to dictionary for API response."""
        result: dict[str, Any] = {
            "error_code": self.error_code,
            "message": self.message,
        }
        if self.details:
            result["details"] = self.details
        if self.suggestion:
            result["suggestion"] = self.suggestion
        return result


class ValidationError(AgentError):
    """
    Exception for input validation failures.

    Raised when user input fails validation rules.
    """

    def __init__(
        self,
        message: str,
        field: str | None = None,
        details: dict[str, Any] | None = None,
    ) -> None:
        """
        Initialize validation error.

        Args:
            message: Error message describing the validation failure.
            field: Name of the field that failed validation.
            details: Additional validation details.
        """
        error_details = details or {}
        if field:
            error_details["field"] = field

        super().__init__(
            message=message,
            error_code="VALIDATION_ERROR",
            details=error_details,
            suggestion="Please check your input and try again.",
        )
        self.field = field


class MCPError(AgentError):
    """
    Exception for MCP (Model Context Protocol) server errors.

    Raised when communication with MCP servers fails.
    """

    def __init__(
        self,
        message: str,
        server: str,
        operation: str | None = None,
        details: dict[str, Any] | None = None,
    ) -> None:
        """
        Initialize MCP error.

        Args:
            message: Error message.
            server: Name of the MCP server that failed.
            operation: The operation that failed.
            details: Additional error details.
        """
        error_details = {"server": server}
        if operation:
            error_details["operation"] = operation
        if details:
            error_details.update(details)

        super().__init__(
            message=message,
            error_code="MCP_ERROR",
            details=error_details,
            suggestion=f"The {server} service may be temporarily unavailable. Please try again later.",
        )
        self.server = server
        self.operation = operation


class AzureCLIError(AgentError):
    """
    Exception for Azure CLI execution errors.

    Raised when Azure CLI commands fail during hypothesis validation.
    """

    def __init__(
        self,
        message: str,
        command: str | None = None,
        exit_code: int | None = None,
        stderr: str | None = None,
        details: dict[str, Any] | None = None,
    ) -> None:
        """
        Initialize Azure CLI error.

        Args:
            message: Error message.
            command: The Azure CLI command that failed.
            exit_code: Command exit code.
            stderr: Standard error output.
            details: Additional error details.
        """
        error_details = details or {}
        if command:
            error_details["command"] = command
        if exit_code is not None:
            error_details["exit_code"] = exit_code
        if stderr:
            error_details["stderr"] = stderr

        super().__init__(
            message=message,
            error_code="AZURE_CLI_ERROR",
            details=error_details,
            suggestion="Ensure Azure CLI is installed and you are authenticated with 'az login'.",
        )
        self.command = command
        self.exit_code = exit_code
        self.stderr = stderr


class OutOfScopeError(AgentError):
    """
    Exception for queries outside the agent's scope.

    Raised when the user asks about non-Azure topics (SC-007).
    """

    def __init__(
        self,
        message: str,
        query: str | None = None,
        detected_topic: str | None = None,
    ) -> None:
        """
        Initialize out of scope error.

        Args:
            message: Error message.
            query: The user's original query.
            detected_topic: The topic detected in the query.
        """
        details: dict[str, Any] = {}
        if query:
            details["query"] = query[:200]  # Truncate for safety
        if detected_topic:
            details["detected_topic"] = detected_topic

        super().__init__(
            message=message,
            error_code="OUT_OF_SCOPE",
            details=details,
            suggestion="This agent specializes in Azure services. Please rephrase your question to focus on Azure-related topics.",
        )
        self.query = query
        self.detected_topic = detected_topic


class AuthenticationError(AgentError):
    """Exception for authentication failures."""

    def __init__(self, message: str = "Authentication required") -> None:
        """Initialize authentication error."""
        super().__init__(
            message=message,
            error_code="AUTHENTICATION_ERROR",
            suggestion="Please provide a valid API key in the X-API-Key header.",
        )


class RateLimitError(AgentError):
    """Exception for rate limiting."""

    def __init__(
        self,
        message: str = "Rate limit exceeded",
        retry_after: int | None = None,
    ) -> None:
        """
        Initialize rate limit error.

        Args:
            message: Error message.
            retry_after: Seconds until the rate limit resets.
        """
        details: dict[str, Any] = {}
        if retry_after:
            details["retry_after"] = retry_after

        super().__init__(
            message=message,
            error_code="RATE_LIMIT_ERROR",
            details=details,
            suggestion="Please wait before making more requests.",
        )
        self.retry_after = retry_after


class ResourceNotFoundError(AgentError):
    """Exception for resource not found errors."""

    def __init__(
        self,
        resource_type: str,
        resource_id: str,
    ) -> None:
        """
        Initialize resource not found error.

        Args:
            resource_type: Type of resource (e.g., "test_plan", "execution").
            resource_id: ID of the resource.
        """
        super().__init__(
            message=f"{resource_type} with ID '{resource_id}' not found",
            error_code="NOT_FOUND",
            details={"resource_type": resource_type, "resource_id": resource_id},
            suggestion=f"Verify the {resource_type} ID is correct.",
        )
        self.resource_type = resource_type
        self.resource_id = resource_id
