"""
Azure AI client utilities for agent framework integration.

Provides AIProjectClient initialization and chat completion helpers
for agents to use the Azure AI Foundry SDK.
"""

from typing import Any

from azure.identity import DefaultAzureCredential
from azure.ai.projects import AIProjectClient
from azure.ai.inference import ChatCompletionsClient
from azure.ai.inference.models import (
    SystemMessage,
    UserMessage,
    AssistantMessage,
    ChatCompletionsToolDefinition,
    FunctionDefinition,
)

from src.config import get_settings
from src.lib.logging import get_logger


logger = get_logger(__name__)


class AIClientManager:
    """
    Manages Azure AI client connections for agents.
    
    Provides:
    - AIProjectClient for agent management
    - ChatCompletionsClient for LLM inference
    - Tool definition helpers
    """
    
    _instance: "AIClientManager | None" = None
    _project_client: AIProjectClient | None = None
    _chat_client: ChatCompletionsClient | None = None
    
    def __new__(cls) -> "AIClientManager":
        """Singleton pattern for client manager."""
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    def __init__(self) -> None:
        """Initialize the AI client manager."""
        self._settings = get_settings()
        self._credential = DefaultAzureCredential()
    
    @property
    def project_client(self) -> AIProjectClient | None:
        """
        Get or create AIProjectClient.
        
        Returns:
            AIProjectClient if configured, None otherwise.
        """
        if self._project_client is None and self._settings.azure_foundry_project_endpoint:
            try:
                self._project_client = AIProjectClient(
                    endpoint=self._settings.azure_foundry_project_endpoint,
                    credential=self._credential,
                )
                logger.info(
                    "AIProjectClient initialized",
                    endpoint=self._settings.azure_foundry_project_endpoint,
                )
            except Exception as e:
                logger.warning(
                    "Failed to initialize AIProjectClient",
                    error=str(e),
                )
        return self._project_client
    
    @property
    def chat_client(self) -> ChatCompletionsClient | None:
        """
        Get or create ChatCompletionsClient for inference.
        
        Returns:
            ChatCompletionsClient if configured, None otherwise.
        """
        if self._chat_client is None and self._settings.azure_foundry_project_endpoint:
            try:
                # Use the inference endpoint from project
                inference_endpoint = f"{self._settings.azure_foundry_project_endpoint}/models"
                self._chat_client = ChatCompletionsClient(
                    endpoint=inference_endpoint,
                    credential=self._credential,
                )
                logger.info("ChatCompletionsClient initialized")
            except Exception as e:
                logger.warning(
                    "Failed to initialize ChatCompletionsClient",
                    error=str(e),
                )
        return self._chat_client
    
    @property
    def is_configured(self) -> bool:
        """Check if AI client is properly configured."""
        return bool(self._settings.azure_foundry_project_endpoint)
    
    @property
    def model_name(self) -> str:
        """Get configured model deployment name."""
        return self._settings.azure_foundry_project_deployment_name
    
    async def generate_completion(
        self,
        system_prompt: str,
        user_message: str,
        context: str | None = None,
        tools: list[ChatCompletionsToolDefinition] | None = None,
    ) -> str:
        """
        Generate a chat completion using the AI client.
        
        Args:
            system_prompt: System message defining agent behavior.
            user_message: User's query or input.
            context: Optional context to include (e.g., search results).
            tools: Optional tool definitions for function calling.
            
        Returns:
            Generated response content.
        """
        if not self.is_configured:
            logger.warning("AI client not configured, returning fallback response")
            return self._fallback_response(user_message)
        
        messages = [SystemMessage(content=system_prompt)]
        
        # Add context if provided
        if context:
            messages.append(UserMessage(content=f"Context:\n{context}"))
        
        messages.append(UserMessage(content=user_message))
        
        try:
            # Use project client's inference endpoint
            if self.project_client:
                response = await self._complete_with_project_client(
                    messages=messages,
                    tools=tools,
                )
                return response
        except Exception as e:
            logger.error(
                "AI completion failed",
                error=str(e),
            )
            return self._fallback_response(user_message)
        
        return self._fallback_response(user_message)
    
    async def _complete_with_project_client(
        self,
        messages: list[SystemMessage | UserMessage | AssistantMessage],
        tools: list[ChatCompletionsToolDefinition] | None = None,
    ) -> str:
        """
        Execute completion using AIProjectClient.
        
        Note: This is a sync operation wrapped for async compatibility.
        """
        # For now, use the inference sub-client
        # In production, this would use the agents API for full orchestration
        try:
            # Convert messages to dict format for API
            message_dicts = []
            for msg in messages:
                if isinstance(msg, SystemMessage):
                    message_dicts.append({"role": "system", "content": msg.content})
                elif isinstance(msg, UserMessage):
                    message_dicts.append({"role": "user", "content": msg.content})
                elif isinstance(msg, AssistantMessage):
                    message_dicts.append({"role": "assistant", "content": msg.content})
            
            # Use project client's inference
            if self.project_client:
                inference = self.project_client.inference
                response = inference.complete(
                    model=self.model_name,
                    messages=message_dicts,
                )
                
                if response.choices and response.choices[0].message:
                    return response.choices[0].message.content or ""
        
        except Exception as e:
            logger.error("Project client completion failed", error=str(e))
            raise
        
        return ""
    
    def _fallback_response(self, user_message: str) -> str:
        """Generate fallback response when AI is not available."""
        return (
            "I'm currently operating in limited mode without AI enhancement. "
            f"Your query was: '{user_message[:100]}...'\n\n"
            "Please configure the Azure AI Foundry endpoint to enable full functionality."
        )


def create_tool_definition(
    name: str,
    description: str,
    parameters: dict[str, Any],
) -> ChatCompletionsToolDefinition:
    """
    Create a tool definition for function calling.
    
    Args:
        name: Function name.
        description: Function description.
        parameters: JSON schema for function parameters.
        
    Returns:
        ChatCompletionsToolDefinition for use with AI client.
    """
    return ChatCompletionsToolDefinition(
        function=FunctionDefinition(
            name=name,
            description=description,
            parameters=parameters,
        )
    )


# Global client manager instance
_ai_client_manager: AIClientManager | None = None


def get_ai_client_manager() -> AIClientManager:
    """
    Get the global AI client manager instance.
    
    Returns:
        AIClientManager singleton instance.
    """
    global _ai_client_manager
    if _ai_client_manager is None:
        _ai_client_manager = AIClientManager()
    return _ai_client_manager
